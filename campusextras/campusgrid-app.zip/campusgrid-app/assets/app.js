// ---- Bottom nav active state ----
document.addEventListener('DOMContentLoaded', () => {
  const page = document.body.dataset.page;
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.nav === page);
  });

  // ---- reveal stagger for list items / cards on load ----
  const revealables = document.querySelectorAll('.quick-card, .list-item, .card, .more-item, .route-step');
  revealables.forEach((el, i) => {
    el.classList.add('reveal');
    el.style.animationDelay = (i * 0.05) + 's';
  });

  // ---- toggle switches ----
  document.querySelectorAll('.switch').forEach(sw => {
    sw.addEventListener('click', () => sw.classList.toggle('on'));
  });

  // ---- count-up numbers ----
  document.querySelectorAll('.count-up').forEach(el => {
    const target = parseFloat(el.dataset.target || '0');
    const suffix = el.dataset.suffix || '';
    const dur = 900;
    const start = performance.now();
    function tick(now) {
      const p = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(target * eased) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });

  // ---- chip row active state ----
  document.querySelectorAll('.chip-row').forEach(row => {
    row.querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', () => {
        row.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
      });
    });
  });

  // ---- live "last updated" ticking ----
  const liveClocks = document.querySelectorAll('.live-seconds');
  if (liveClocks.length) {
    let secs = 0;
    setInterval(() => {
      secs += 4;
      liveClocks.forEach(el => { el.textContent = secs + 's ago'; });
    }, 4000);
  }

  // ---- assistant chat demo ----
  const chatScroll = document.getElementById('chatScroll');
  if (chatScroll) {
    const responses = {
      "where's my next class?": {
        text: "Your next class is Thermodynamics II in DK12, Block C — 6 minutes away on foot.",
        route: "Start route to DK12 →"
      },
      "is the library busy right now?": {
        text: "Main Library is at 62% capacity right now. Level 2 quiet zone has the most open seats.",
        route: "Navigate to Library, Level 2 →"
      },
      "accessible route to the hall?": {
        text: "Here's a step-free route to Dewan Utama — ramps and lift access included, adds about 3 minutes.",
        route: "Start accessible route →"
      }
    };
    document.querySelectorAll('.prompt-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const q = chip.textContent.trim();
        addBubble(q, 'user');
        chip.parentElement.style.display = 'none';
        setTimeout(() => {
          const r = responses[q.toLowerCase()] || { text: "Let me look that up on the grid for you.", route: null };
          addBubble(r.text, 'bot', r.route);
        }, 550);
      });
    });
    function addBubble(text, who, route) {
      const b = document.createElement('div');
      b.className = 'bubble ' + who + ' reveal';
      b.textContent = text;
      if (route) {
        const chipEl = document.createElement('div');
        chipEl.className = 'route-chip';
        chipEl.textContent = route;
        b.appendChild(chipEl);
      }
      chatScroll.appendChild(b);
      chatScroll.scrollTop = chatScroll.scrollHeight;
    }
  }
});
